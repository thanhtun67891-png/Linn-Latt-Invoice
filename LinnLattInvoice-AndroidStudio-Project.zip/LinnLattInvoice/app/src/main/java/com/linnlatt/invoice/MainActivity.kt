package com.linnlatt.invoice

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF123B63)
private val Blue = Color(0xFF1976D2)
private val Pale = Color(0xFFF2F7FC)
private val Ink = Color(0xFF1B2B3A)

 data class Product(val name: String, val mm: String, val price: Double = 0.0)
 data class LineItem(val name: String, val qty: Int, val price: Double) { val total get() = qty * price }
 data class Invoice(val id: String, val date: String, val customer: String, val phone: String, val items: List<LineItem>, val discount: Double, val paid: Double) {
    val subtotal get() = items.sumOf { it.total }
    val total get() = (subtotal - discount).coerceAtLeast(0.0)
    val due get() = (total - paid).coerceAtLeast(0.0)
    val status get() = if (due <= 0.0) "PAID" else if (paid > 0.0) "PARTIAL" else "UNPAID"
 }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { InvoiceApp() } }
}

private val catalog = listOf(
    "Circumcision Stapler" to "Circumcision Stapler", "Skin Stapler" to "Skin Stapler",
    "PRP Tube (ACD+Gel) 10ml" to "PRP Tube (ACD+Gel) 10ml", "PRP Tube (ACD+Gel) 15ml" to "PRP Tube (ACD+Gel) 15ml",
    "PRP Tube (ACD+Gel+Biotin) 10ml" to "PRP Tube (ACD+Gel+Biotin) 10ml", "PRP Tube (ACD+Gel+HA) 10ml" to "PRP Tube (ACD+Gel+HA) 10ml",
    "PRF Tube 10ml" to "PRF Tube 10ml", "Plain Tube 10ml" to "Plain Tube 10ml", "Gel & Clot Activator Tube 10ml" to "Gel & Clot Activator Tube 10ml",
    "Mole Removal Plasma Machine" to "Mole Removal Plasma Machine", "Mole Removal Machine Handle" to "Mole Removal Machine Handle",
    "Electric Cautery Device" to "Electric Cautery Device", "Electric Cautery Tips" to "Electric Cautery Tips",
    "Disposable Diathermy Pencil" to "Disposable Diathermy Pencil", "Reusable Diathermy Pencil" to "Reusable Diathermy Pencil",
    "Reusable Bipolar Forceps" to "Reusable Bipolar Forceps", "Reusable Bipolar Cable" to "Reusable Bipolar Cable",
    "Reusable Diathermy Patient Plate" to "Reusable Diathermy Patient Plate", "Ahanvos Diathermy 300W" to "Ahanvos Diathermy 300W",
    "Ear Piercing Gun" to "Ear Piercing Gun", "Blood Collection Butterfly Needle" to "Blood Collection Butterfly Needle",
    "Sharps Box 8L" to "Sharps Box 8L", "Mole Removal Plasma Pen" to "Mole Removal Plasma Pen", "Mole Removal Pen Needle" to "Mole Removal Pen Needle",
    "Meso Needle" to "Meso Needle", "Stethoscope" to "Stethoscope", "Laparoscopic Trocar 5mm" to "Laparoscopic Trocar 5mm", "Laparoscopic Trocar 10mm" to "Laparoscopic Trocar 10mm"
).map { Product(it.first, it.second) }

@Composable fun InvoiceApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("linn_latt_invoice", Context.MODE_PRIVATE) }
    var burmese by remember { mutableStateOf(prefs.getBoolean("burmese", false)) }
    var invoices by remember { mutableStateOf(loadInvoices(prefs)) }
    var page by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf<Invoice?>(null) }
    fun save(list: List<Invoice>) { invoices = list; prefs.edit().putString("invoices", JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()).apply() }
    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy, background = Pale, surface = Color.White)) {
        Scaffold(containerColor = Pale, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text(if (burmese) "ပင်မ" else "Home") })
                NavigationBarItem(selected = page == "history", onClick = { page = "history" }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text(if (burmese) "ဘောင်ချာ" else "Invoices") })
                NavigationBarItem(selected = page == "reports", onClick = { page = "reports" }, icon = { Icon(Icons.Default.Assessment, null) }, label = { Text(if (burmese) "စာရင်းချုပ်" else "Reports") })
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (page) {
                    "new" -> NewInvoiceScreen(burmese, onBack = { page = "home" }, onSave = { inv -> save(listOf(inv) + invoices); page = "history"; selected = inv })
                    "history" -> HistoryScreen(burmese, invoices, onNew = { page = "new" }, onOpen = { selected = it; page = "detail" })
                    "reports" -> ReportsScreen(burmese, invoices)
                    "detail" -> selected?.let { InvoiceDetailScreen(burmese, it, onBack = { page = "history" }, onPdf = { createAndSharePdf(ctx, it, burmese) }, onPayment = { amount -> save(invoices.map { x -> if (x.id == it.id) x.copy(paid = (x.paid + amount).coerceAtMost(x.total)) else x }) ; selected = invoices.firstOrNull { x -> x.id == it.id }?.let { x -> x.copy(paid = (x.paid + amount).coerceAtMost(x.total)) } }) }
                    else -> HomeScreen(burmese, invoices, onNew = { page = "new" }, onHistory = { page = "history" }, onLanguage = { burmese = !burmese; prefs.edit().putBoolean("burmese", burmese).apply() })
                }
            }
        }
    }
}

@Composable private fun HomeScreen(mm: Boolean, invoices: List<Invoice>, onNew: () -> Unit, onHistory: () -> Unit, onLanguage: () -> Unit) {
    val sales = invoices.sumOf { it.total }; val due = invoices.sumOf { it.due }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painter = painterResource(R.drawable.linn_latt_logo), contentDescription = "Linn Latt Medical Products logo", modifier = Modifier.size(68.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.width(8.dp))
                Column { Text("LINN LATT", color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp); Text("MEDICAL PRODUCTS", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, fontSize = 10.sp) }
            }
            OutlinedButton(onClick = onLanguage) { Icon(Icons.Default.Language, null); Spacer(Modifier.width(5.dp)); Text(if (mm) "English" else "မြန်မာ") }
        } }
        item { Text(if (mm) "ဘောင်ချာစီမံခန့်ခွဲမှု" else "Invoice Management", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard(if (mm) "စုစုပေါင်းရောင်းရငွေ" else "Total Sales", money(sales), Modifier.weight(1f)); MetricCard(if (mm) "ကျန်ငွေ" else "Outstanding", money(due), Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard(if (mm) "ဘောင်ချာအရေအတွက်" else "Invoices", invoices.size.toString(), Modifier.weight(1f)); MetricCard(if (mm) "ပေးချေပြီး" else "Paid Invoices", invoices.count { it.status == "PAID" }.toString(), Modifier.weight(1f)) } }
        item { Button(onClick = onNew, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text(if (mm) "ဘောင်ချာအသစ်ပြုလုပ်ရန်" else "Create New Invoice", fontSize = 16.sp) } }
        item { OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.Description, null); Spacer(Modifier.width(8.dp)); Text(if (mm) "ဘောင်ချာမှတ်တမ်းများ" else "View Invoice History") } }
        item { BusinessInfo(mm) }
        item { Text(if (mm) "မှတ်ချက် - ဒေတာများကို ဖုန်းထဲတွင် သိမ်းဆည်းထားပါသည်။" else "Your invoices are stored locally on this device.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) { Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(14.dp)) { Text(label, color = Color.Gray, fontSize = 12.sp); Spacer(Modifier.height(8.dp)); Text(value, color = Navy, fontWeight = FontWeight.Bold, fontSize = 19.sp) } } }
@Composable private fun BusinessInfo(mm: Boolean) { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Text(if (mm) "လုပ်ငန်းအချက်အလက်" else "Business Details", fontWeight = FontWeight.Bold, color = Navy); Spacer(Modifier.height(8.dp)); Text("Linn Latt Medical Products", fontWeight = FontWeight.SemiBold); Text("No.8, Ahyoe Kone Street, Tamwe"); Text("095067891  |  09765067891") } } }

@Composable private fun NewInvoiceScreen(mm: Boolean, onBack: () -> Unit, onSave: (Invoice) -> Unit) {
    var customer by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var address by remember { mutableStateOf("") }
    var product by remember { mutableStateOf(catalog.first().name) }; var qty by remember { mutableStateOf("1") }; var price by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("0") }; var paid by remember { mutableStateOf("0") }; var lines by remember { mutableStateOf(listOf<LineItem>()) }
    val total = (lines.sumOf { it.total } - (discount.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)
    Column(Modifier.fillMaxSize()) {
        TopBar(if (mm) "ဘောင်ချာအသစ်" else "New Invoice", onBack)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Field(if (mm) "ဖောက်သည်အမည် *" else "Customer Name *", customer, { customer = it }) }
            item { Field(if (mm) "ဖုန်းနံပါတ်" else "Phone Number", phone, { phone = it }, KeyboardType.Phone) }
            item { Field(if (mm) "လိပ်စာ" else "Address", address, { address = it }) }
            item { Text(if (mm) "ပစ္စည်းထည့်ရန်" else "Add Products", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            item { var expanded by remember { mutableStateOf(false) }; ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) { OutlinedTextField(value = product, onValueChange = {}, readOnly = true, label = { Text(if (mm) "ပစ္စည်းရွေးပါ" else "Select Product") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth(), shape = RoundedCornerShape(12.dp)); ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { catalog.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = { product = p.name; expanded = false }) } } } }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Field(if (mm) "အရေအတွက်" else "Qty", qty, { qty = it }, KeyboardType.Number, Modifier.weight(1f)); Field(if (mm) "တစ်ခုဈေးနှုန်း" else "Unit Price (MMK)", price, { price = it }, KeyboardType.Decimal, Modifier.weight(2f)) } }
            item { OutlinedButton(onClick = { val q = qty.toIntOrNull() ?: 0; val p = price.toDoubleOrNull() ?: 0.0; if (q > 0 && p > 0) { lines = lines + LineItem(product, q, p); qty = "1"; price = "" } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text(if (mm) "ပစ္စည်းထည့်မည်" else "Add Item") } }
            items(lines) { line -> Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(line.name, fontWeight = FontWeight.SemiBold); Text("${line.qty} × ${money(line.price)}", color = Color.Gray, fontSize = 12.sp) }; Text(money(line.total), fontWeight = FontWeight.Bold); Text(" ✕", color = Color.Red, modifier = Modifier.clickable { lines = lines - line }) } } }
            item { Field(if (mm) "လျှော့ဈေး (MMK)" else "Discount (MMK)", discount, { discount = it }, KeyboardType.Decimal) }
            item { Field(if (mm) "လက်ခံရရှိငွေ (MMK)" else "Amount Received (MMK)", paid, { paid = it }, KeyboardType.Decimal) }
            item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(14.dp)) { SummaryRow(if (mm) "ပစ္စည်းဖိုး" else "Subtotal", money(lines.sumOf { it.total })); SummaryRow(if (mm) "လျှော့ဈေး" else "Discount", money(discount.toDoubleOrNull() ?: 0.0)); HorizontalDivider(); SummaryRow(if (mm) "ကျသင့်ငွေ" else "Grand Total", money(total), true); SummaryRow(if (mm) "ကျန်ငွေ" else "Balance Due", money((total - (paid.toDoubleOrNull() ?: 0.0)).coerceAtLeast(0.0)), true) } } }
        }
        Button(onClick = { if (customer.isNotBlank() && lines.isNotEmpty()) { val date = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date()); onSave(Invoice("LL-${System.currentTimeMillis().toString().takeLast(7)}", date, customer, phone, lines, discount.toDoubleOrNull() ?: 0.0, (paid.toDoubleOrNull() ?: 0.0).coerceAtMost(total))) } }, enabled = customer.isNotBlank() && lines.isNotEmpty(), modifier = Modifier.fillMaxWidth().padding(16.dp).height(54.dp), shape = RoundedCornerShape(14.dp)) { Text(if (mm) "ဘောင်ချာသိမ်းမည်" else "Save Invoice") }
    }
}

@Composable private fun Field(label: String, value: String, change: (String) -> Unit, keyboard: KeyboardType = KeyboardType.Text, modifier: Modifier = Modifier) { OutlinedTextField(value, change, label = { Text(label) }, modifier = modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboard), shape = RoundedCornerShape(12.dp)) }
@Composable private fun TopBar(title: String, back: () -> Unit) { Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }; Text(title, color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold) } }
@Composable private fun SummaryRow(label: String, value: String, bold: Boolean = false) { Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = if (bold) Navy else Color.Gray, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal); Text(value, color = Navy, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium) } }

@Composable private fun HistoryScreen(mm: Boolean, invoices: List<Invoice>, onNew: () -> Unit, onOpen: (Invoice) -> Unit) {
    Column(Modifier.fillMaxSize()) { TopBar(if (mm) "ဘောင်ချာမှတ်တမ်း" else "Invoice History", onNew); if (invoices.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(if (mm) "ဘောင်ချာမရှိသေးပါ" else "No invoices yet", color = Color.Gray) } else LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) { items(invoices) { inv -> Card(Modifier.fillMaxWidth().clickable { onOpen(inv) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(14.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(inv.id, fontWeight = FontWeight.Bold, color = Navy); StatusChip(inv.status) }; Text(inv.customer, fontWeight = FontWeight.SemiBold); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(inv.date, color = Color.Gray, fontSize = 12.sp); Text(money(inv.total), fontWeight = FontWeight.Bold) }; if (inv.due > 0) Text("Due: ${money(inv.due)}", color = Color(0xFFB45309), fontSize = 12.sp) } } } } }
}
@Composable private fun StatusChip(status: String) { val c = when(status) { "PAID" -> Color(0xFF16834A); "PARTIAL" -> Color(0xFFB7791F); else -> Color(0xFFB42318) }; Surface(color = c.copy(alpha = .12f), shape = RoundedCornerShape(20.dp)) { Text(status, color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)) } }

@Composable private fun InvoiceDetailScreen(mm: Boolean, inv: Invoice, onBack: () -> Unit, onPdf: () -> Unit, onPayment: (Double) -> Unit) {
    var amount by remember { mutableStateOf("") }; var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) { TopBar(if (mm) "ဘောင်ချာအသေးစိတ်" else "Invoice Details", onBack); LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { BusinessInfo(mm) }; item { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(16.dp)) { Text(inv.id, color = Navy, fontWeight = FontWeight.Bold); Text(inv.date, color = Color.Gray); Spacer(Modifier.height(12.dp)); Text(inv.customer, fontWeight = FontWeight.Bold); Text(inv.phone); HorizontalDivider(Modifier.padding(vertical = 10.dp)); inv.items.forEach { SummaryRow("${it.name}  × ${it.qty}", money(it.total)) }; HorizontalDivider(); SummaryRow("Subtotal", money(inv.subtotal)); SummaryRow("Discount", money(inv.discount)); SummaryRow("Total", money(inv.total), true); SummaryRow("Paid", money(inv.paid)); SummaryRow("Balance", money(inv.due), true); StatusChip(inv.status) } } }
        item { Button(onClick = onPdf, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text(if (mm) "PDF ထုတ်ပြီး မျှဝေရန်" else "Generate & Share PDF") } }
        if (inv.due > 0) item { OutlinedButton(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) { Text(if (mm) "ငွေပေးချေမှု မှတ်တမ်းတင်ရန်" else "Record Payment") } }
    } }
    if (show) AlertDialog(onDismissRequest = { show = false }, title = { Text(if (mm) "ငွေလက်ခံရရှိမှု" else "Record Payment") }, text = { OutlinedTextField(amount, { amount = it }, label = { Text("Amount (MMK)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)) }, confirmButton = { TextButton(onClick = { val a = amount.toDoubleOrNull(); if (a != null && a > 0) onPayment(a); show = false }) { Text("Save") } }, dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } })
}

@Composable private fun ReportsScreen(mm: Boolean, invoices: List<Invoice>) {
    val today = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date())
    val month = SimpleDateFormat("MMM yyyy", Locale.ENGLISH).format(Date())
    val todayInvoices = invoices.filter { it.date == today }
    val monthInvoices = invoices.filter { it.date.endsWith(month) }
    val paid = invoices.sumOf { it.paid }; val sales = invoices.sumOf { it.total }; val outstanding = invoices.sumOf { it.due }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(if (mm) "အရောင်းစာရင်းချုပ်" else "Sales Reports", fontSize = 23.sp, color = Navy, fontWeight = FontWeight.Bold) }
        item { MetricCard(if (mm) "ယနေ့ရောင်းရငွေ" else "Today's Sales", money(todayInvoices.sumOf { it.total })) }
        item { MetricCard(if (mm) "ယခုလရောင်းရငွေ" else "This Month's Sales", money(monthInvoices.sumOf { it.total })) }
        item { MetricCard(if (mm) "စုစုပေါင်းရောင်းရငွေ" else "Total Invoiced Sales", money(sales)) }
        item { MetricCard(if (mm) "လက်ခံရရှိငွေ" else "Payments Received", money(paid)) }
        item { MetricCard(if (mm) "ရရန်ကျန်ငွေ" else "Outstanding Balance", money(outstanding)) }
        item { MetricCard(if (mm) "ဘောင်ချာစုစုပေါင်း" else "Invoice Count", invoices.size.toString()) }
        item { Text(if (mm) "ငွေပေးချေမှုအခြေအနေ" else "Payment Status", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Paid: ${invoices.count { it.status == "PAID" }}"); Text("Partial: ${invoices.count { it.status == "PARTIAL" }}"); Text("Unpaid: ${invoices.count { it.status == "UNPAID" }}") } }
    }
}

private fun money(v: Double) = "${String.format(Locale.US, "%,.0f", v)} MMK"
private fun Invoice.toJson() = JSONObject().apply { put("id", id); put("date", date); put("customer", customer); put("phone", phone); put("discount", discount); put("paid", paid); put("items", JSONArray().apply { items.forEach { put(JSONObject().put("name", it.name).put("qty", it.qty).put("price", it.price)) } }) }
private fun loadInvoices(prefs: android.content.SharedPreferences): List<Invoice> = try { val a = JSONArray(prefs.getString("invoices", "[]")); (0 until a.length()).map { i -> val o = a.getJSONObject(i); val arr = o.getJSONArray("items"); Invoice(o.getString("id"), o.getString("date"), o.getString("customer"), o.optString("phone"), (0 until arr.length()).map { j -> val x = arr.getJSONObject(j); LineItem(x.getString("name"), x.getInt("qty"), x.getDouble("price")) }, o.optDouble("discount"), o.optDouble("paid")) } } catch (_: Exception) { emptyList() }

private fun createAndSharePdf(ctx: Context, inv: Invoice, mm: Boolean) {
    val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); val c = page.canvas
    val p = Paint().apply { color = android.graphics.Color.rgb(18,59,99); textSize = 23f; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    val logo = BitmapFactory.decodeResource(ctx.resources, R.drawable.linn_latt_logo)
    c.drawBitmap(logo, null, android.graphics.RectF(40f, 25f, 135f, 120f), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    c.drawText("LINN LATT MEDICAL PRODUCTS", 150f, 55f, p)
    p.textSize = 11f; p.typeface = Typeface.DEFAULT; p.color = android.graphics.Color.DKGRAY
    c.drawText("No.8, Ahyoe Kone Street, Tamwe", 150f, 78f, p); c.drawText("095067891  |  09765067891", 150f, 96f, p)
    p.textSize = 19f; p.typeface = Typeface.BOLD; p.color = android.graphics.Color.BLACK; c.drawText(if (mm) "INVOICE / ဘောင်ချာ" else "INVOICE", 40f, 155f, p)
    p.textSize = 12f; p.typeface = Typeface.DEFAULT; c.drawText("Invoice: ${inv.id}", 40f, 185f, p); c.drawText("Date: ${inv.date}", 40f, 204f, p); c.drawText("Customer: ${inv.customer}", 40f, 223f, p); c.drawText("Phone: ${inv.phone}", 40f, 242f, p)
    var y = 290f; p.typeface = Typeface.BOLD; c.drawText("Description", 40f, y, p); c.drawText("Qty", 360f, y, p); c.drawText("Unit Price", 405f, y, p); c.drawText("Amount", 505f, y, p); y += 15f; c.drawLine(40f, y, 555f, y, p); y += 23f; p.typeface = Typeface.DEFAULT
    inv.items.forEach { line -> c.drawText(line.name.take(42), 40f, y, p); c.drawText(line.qty.toString(), 360f, y, p); c.drawText(String.format(Locale.US, "%,.0f", line.price), 405f, y, p); c.drawText(String.format(Locale.US, "%,.0f", line.total), 505f, y, p); y += 24f }
    y += 10f; c.drawLine(350f, y, 555f, y, p); y += 24f
    fun row(label: String, value: Double, bold: Boolean = false) { p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; c.drawText(label, 360f, y, p); c.drawText(String.format(Locale.US, "%,.0f MMK", value), 465f, y, p); y += 23f }
    row("Subtotal", inv.subtotal); row("Discount", inv.discount); row("GRAND TOTAL", inv.total, true); row("Paid", inv.paid); row("BALANCE DUE", inv.due, true)
    p.textSize = 10f; p.typeface = Typeface.DEFAULT; c.drawText("Thank you for choosing Linn Latt Medical Products.", 40f, 790f, p)
    doc.finishPage(page)
    val dir = File(ctx.cacheDir, "invoices").apply { mkdirs() }; val file = File(dir, "${inv.id}.pdf"); file.outputStream().use { doc.writeTo(it) }; doc.close()
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", file)
    val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    ctx.startActivity(Intent.createChooser(intent, "Share Invoice PDF"))
}
