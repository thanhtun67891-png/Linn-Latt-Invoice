# Linn Latt Medical Products – Invoice Manager

Android Studio project for a bilingual (English / Myanmar) offline-first invoice app.

## Included
- Business header prefilled with Linn Latt Medical Products, No.8 Ahyoe Kone Street, Tamwe, and both phone numbers.
- Create invoices with customer details, line items, quantities, unit prices, discounts, amount received, and balance due.
- Seeded medical supplies catalog based on the product list provided by the business.
- Paid / Partial / Unpaid payment status and payment recording.
- Invoice history and sales summary.
- Generate and share invoice PDFs through Android's share sheet.
- Local persistence using Android SharedPreferences; no account or internet required.
- English / Myanmar language toggle (some PDF labels and less prominent utility text remain English).

## Build an APK
This workspace does not include the Android SDK or Gradle executable, so an installable APK has **not** been compiled here.

1. Install Android Studio (current stable) on a computer.
2. Open this folder (`LinnLattInvoice`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Important notes
- Prices are intentionally blank in the product catalog; enter the current selling price on each invoice.
- Records are stored on this device only. Back up or export records before changing phones or uninstalling the app.
- This is a starter version. Test invoice totals, PDF layout, and payment workflows with sample records before using it for official accounting.

## Business logo
The supplied Linn Latt logo is included at `app/src/main/res/drawable-nodpi/linn_latt_logo.png`. It appears in the app dashboard and on generated invoice PDFs.
